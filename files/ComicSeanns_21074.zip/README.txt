You will need to delete the original ctm folders labelled:

3 - [dirt]
12 - [sand]
13 - [gravel]