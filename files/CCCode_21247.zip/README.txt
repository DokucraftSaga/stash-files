This is a proof of concept, animated model for vanilla Minecraft that I made back in 2016.
The model itself is simply all of the different frames of the animation combined.
Each frame in the animation uses a different part of the texture. So, to make it animate, it uses an animation strip that makes all except one frame visible at a time.
Note that the animation strip included here was just made to prove the concept and is probably far from optimal. It's streched because each frame needs to be square.

This model should work with any blocks that support transparent textures. When testing, I just used the glass block.

Keep in mind that models like these are really bad for performance and should probably not be used for anything.