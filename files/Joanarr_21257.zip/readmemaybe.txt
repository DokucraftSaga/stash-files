Both Syndi Shan X and I worked on these villagers and zombie textures. Syndi did the professions and zombie villagers, I did the biome types and the diamond promotion master crown. Thanks for downloading!

		~Joanarr