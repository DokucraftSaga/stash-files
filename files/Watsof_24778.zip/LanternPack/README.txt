Created by Watsof

Small Dokucraft add-on for Minecraft 1.16. 
Additions:

	- 3D chains added to hanging lanterns;
	- 3D inventory model for Soul-lanterns;
	- animated texture for regular lanterns.

You can freely modify chain/lantern texture and they should still link seamlessly, as long as the model stays the same.


Credits:

https://dokucraft.co.uk/stash/ 

iiKraze (#24431) - chains model and texture
Tetsune (#23716) - soul lantern texture
