Model files created by Starseeker
Textures derived from existing Dokucraft TSC assets