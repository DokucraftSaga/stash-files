Yah dude, I finally finished the sword.
This is a 3D Model for the diamond sword. I've added extra textures and model files to make the sword appear deteriorated according to its durability.
Created by Joanarr
Special thanks to CCCode and SyndiShanX, if they hadn't helped me with the code for the deterioration models, the sword would've appeared brand new throughout all its life in the game.
Enjoy!