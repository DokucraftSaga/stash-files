Thanks for getting my totem model.
The statue can be changed to whatever skin you like as long as the skin image you use is a 1.8 square image skin.
The model does include the overlays on the skin
To change it, grab your skin, rename it totem_statue , then place the png skin in your resource pack
in assets/minecraft/textures/item
Thanks, and enjoy!