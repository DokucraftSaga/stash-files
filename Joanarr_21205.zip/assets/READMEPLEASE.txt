These models use the entity textures of the horse as the horse armor item in your hand.
Not only does it give it a unique 3D flair, it also makes updating horse armor textures easier since
the item textures are no longer required. If you wish to change your horse armor texture, with these models
you will only have to update the texture for the entity.
The leather horse armor (for 1.14) model is included as well, but since as of right now (April/3/2019), the leather horse armor textures
are still being worked on, the textures are NOT included. Hopefully, once the leather entity textures are finished,
I can update this model folder to include them.
The leather model is ready, but the textures are not. Remember that.
Thanks for downloading this model!

		--Joanarr